﻿using System.ComponentModel.DataAnnotations;

namespace entity_framework.Models.Cascade
{
    public class Country
    {
      
        public int Id { get; set; }

        public string Name  { get; set; }
    }
}
