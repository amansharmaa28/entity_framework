using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace entity_framework.Views.Home
{
    public class listviewModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
